#include "GameTextures.h"

 SDL_Texture* GameTextures::loadTex(const char* path, SDL_Renderer* renderer) {
	SDL_Surface* objSurf = SDL_LoadBMP(path);
	SDL_Texture* objTex = SDL_CreateTextureFromSurface(renderer, objSurf);
	SDL_FreeSurface(objSurf);
	return objTex;
}