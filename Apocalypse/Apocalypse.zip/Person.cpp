#include "Person.h"

Person::Person(const char* path, SDL_Renderer* renderer) {
	this->renderer = renderer;
	personTex = GameTextures::loadTex(path, renderer);
}

void Person::display() {
	SDL_RenderCopy(renderer, personTex, NULL, &personRect);
}

void Person::act() {
	x = 0;
	y = 0;
	personRect.w = 64;
	personRect.h = 64;
	personRect.x = x;
	personRect.y = y;
}