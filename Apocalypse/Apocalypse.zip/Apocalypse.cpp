#include "Gameplay.h"

int main(int argc, char* argv[]) {
	int FPS = 60;
	int delayFrame = 1000 / FPS;
	Uint32 frameBegin;
	int frameTime;
	Gameplay *game = new Gameplay();
	game->createGame(680, 680, false);
	while (game->active()) {
		frameBegin = SDL_GetTicks();
		game->eventHandle();
		game->update();
		game->display();
		frameTime = SDL_GetTicks() - frameBegin;

		if (delayFrame > frameTime) {
			SDL_Delay(delayFrame - frameTime);
		}
	}
	game->clear();
	return 0;
}