#pragma once
#include "SDL.h"
#include "GameTextures.h"
class Person
{
private:
	int x, y;
	SDL_Rect personRect;
	SDL_Texture* personTex;
	SDL_Renderer* renderer;
public:
	Person(const char* path, SDL_Renderer* renderer);

	void act();
	void display();
};

