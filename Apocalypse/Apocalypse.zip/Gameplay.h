#pragma once
#include "Person.h"
#include <iostream>
#include <SDL.h>
#include "GameTextures.h"


class Gameplay {
private:
	bool isActive;
	Person* survivor;
	SDL_Window* window;
	SDL_Renderer* renderer;
	int cnt;
public:
	void createGame(int width, int height, bool fullscreen);
	void eventHandle();
	void update();
	void display();
	void clear();
	bool active() {
		return isActive;
	}
	
};

