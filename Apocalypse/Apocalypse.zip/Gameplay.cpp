#include "Gameplay.h"

void Gameplay::createGame(int width, int height, bool fullscreen) {
	int flags = 0;
	
	if (fullscreen) {
		flags = SDL_WINDOW_FULLSCREEN;
	}

	if (SDL_Init(SDL_INIT_EVERYTHING) < 0) {
		std::cout << "SDL could not be initialized: " << SDL_GetError();
		isActive = false;
	}
	else {
		std::cout << "SDL system is ready\n";
		window = SDL_CreateWindow("Apocalypse", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, width, height, flags);
		renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
		isActive = true;
	}

	//survivorTex = GameTextures::loadTex("D:/Textures/Survivor.bmp", renderer);
	survivor = new Person("D:/Textures/Survivor.bmp", renderer);
}

void Gameplay::eventHandle() {
	SDL_Event event;
	SDL_PollEvent(&event);

	switch (event.type) {
		case SDL_QUIT:
			isActive = false;
			break;
	}
	
}

void Gameplay::display() {
	SDL_SetRenderDrawColor(renderer, 0, 0, 0xFF, SDL_ALPHA_OPAQUE);
	SDL_RenderClear(renderer);
	survivor->display();
	SDL_RenderPresent(renderer);
}

void Gameplay::update() {
	survivor->act();
}

void Gameplay::clear() {
	SDL_DestroyWindow(window);
	SDL_DestroyRenderer(renderer);
	SDL_Quit();
}
