#pragma once
#include "SDL.h"
class GameTextures
{
public:
	static SDL_Texture* loadTex(const char* path, SDL_Renderer* renderer);
};

